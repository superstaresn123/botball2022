#include <kipr/wombat.h>
#include "library_2022.h"
int main (){
while(digital(0) == 0){
  motor (0,30);
  motor (3,30);    
}
reverse(8000);
ao();
turn_left(4600);
while (analog(2)<2870){
   motor (0,30);
   motor (3,30);    
}
ao();
msleep(1000);
printf("found black line\n");
turn_left(4800);
printf("turnt left\n");
ao();
while(digital(0) == 0 ){
    while (analog(1) > 3875){
   		motor (0,50);
   		motor (3,30);    
	}
	while (analog(1) < 3875){
   		motor (0,30);
      	motor (3,50);
	}
}
return 0;
}


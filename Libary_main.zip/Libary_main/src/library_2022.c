#include <kipr/wombat.h>
#include "library_2022.h"
void drive(x){
    motor (0,50);
    motor (3,50);
    msleep (x); 
    ao();
    msleep(1000);
}
void turn_left(x){
  motor(0,30);
  msleep(x);
  ao();
  msleep(1000);
}
void turn_right(x){
  motor(3,100);
  msleep(x);
  ao();
  msleep(1000);
}
void grab(x,y){
     enable_servos();
    //start poition
  set_servo_position(3, 1000);
  set_servo_position(0, 100);
  msleep(500);
    //grab block
  set_servo_position(0,y);
  msleep(1000);
  set_servo_position(3,x);
  msleep(5000);
  //bring block back up
  set_servo_position(0, 100);
  msleep(1500);
}
void findline(){
    printf("Find the black line\n");
while (analog(5) < 3800){
    if(digital(0) == 1){
         motor (0,-50);
         motor (3,-50);
         msleep(1000);
		 turn_right(900);
    }
    motor (0,50);
    motor (3,50);
}
printf("found black line\n");
}
void reverse(x){
 motor (0,-30);
 motor (3,-30);
 msleep(x);    
}